public class Main {
    public static void main(String[] args) {
        System.out.println(5%4);
        System.out.println(15%3);
        boolean n = 2%2==0;
        System.out.println(n);
        boolean m = 7%2==0;
        System.out.println(m);
        boolean v = 13%2==0;
        System.out.println(v);
        boolean f = 14%2==0;
        System.out.println(f);
        System.out.println();
        System.out.println();

        int num = 1785 % 10;
        System.out.println(num);

    }
}