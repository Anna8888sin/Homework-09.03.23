public class Main {
    public static void main(String[] args) {
        byte a1 = 127;
        System.out.println(a1);
        int a2 = 127 + 1;
        System.out.println(a2);

    }
}