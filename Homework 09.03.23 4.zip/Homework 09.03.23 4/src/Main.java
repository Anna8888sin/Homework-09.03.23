public class Main {
    public static void main(String[] args) {
        int i1 = 24;
        int i2 = 35;
        long l1 = 46;
        long l2 = 57;
        double d1 = 11;
        double d2 = 33;
        float f1 = 95;
        float f2 = 94;
        System.out.println();
        System.out.println();
        System.out.println();

        int summa1 = i1 + i2;
        long summa2 = l1 + l2;
        long summa3 = i1 + l1;
        float summa4 = i1 + f1;
        double summa5 = i1 + d1;
        double summa6 = l1 + d1;
        System.out.println(summa1);
        System.out.println(summa2);
        System.out.println(summa3);
        System.out.println(summa4);
        System.out.println(summa5);
        System.out.println(summa6);

    }
}