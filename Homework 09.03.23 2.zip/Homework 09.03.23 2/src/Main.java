public class Main {
    public static void main(String[] args) {
        int a = 135;
        int b = 1357;
        int summa = a + b;
        System.out.println(summa);
        int a1 = 135;
        int b1 = 1357;
        int delenie = b1 / a1;
        System.out.println(delenie);
        int a2 = 135;
        int b2 = 1357;
        int vichet = b1 - a1;
        System.out.println(vichet);
        int a3 = 135;
        int b3 = 1357;
        int mno = b1 * a1;
        System.out.println(mno);

    }
}