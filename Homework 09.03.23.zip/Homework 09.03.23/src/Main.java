public class Main {
    static final char Day = 'a';
    static final char Night = 'b';
    public static void main(String[] args) {
        boolean bln = true;
        byte bte = 125;
        short shot =2468;
        int it = 13579;
        long lng = 123579;
        float flt = 25.7f;
        double dbl = 3.75;
        char chr = Day  ;
        System.out.println(bln);
        System.out.println(bte);
        System.out.println(shot);
        System.out.println(it);
        System.out.println(lng);
        System.out.println(flt);
        System.out.println(dbl);
        System.out.println(chr);
        it = it / 5;
        System.out.println(it);
        dbl = dbl*2;
        System.out.println(dbl);
        chr = Night;
        System.out.println(chr);
    }
}